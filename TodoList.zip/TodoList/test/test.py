# import csv
# print("hello world")

# with open('names.csv', 'w', newline='') as csvfile:
#     fieldnames = ['first_name', 'last_name']
#     writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
#     writer.writeheader()
#     data = {
#         'first_name' : "ali" ,
#         'last_name' : "hoseini"}
#     writer.writerow (data)



# with open('names.csv', 'r', newline='') as csvfile:
#         reader = csv.DictReader(csvfile)
    
#         for row in reader:
#             print(row)

    
# test = [1,2,4,5,6,7]
# print(test[3])

# def adad ():
#     x = 9
#     c = 10
#     return c

# print(adad())
# print()


adad = "1 4 5 6"
adadlist = adad.split()
list2 = []
for i in adadlist:
    list2.append(int(i))
print(list2)