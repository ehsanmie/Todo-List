import csv 
import os
from datetime import datetime


fieldname= ["title" , "explain" , "priority" , "date" , "done"]

def get_date():


    while True:

        date_text = input("tarikh(yyyy-mm-dd) or today: ").strip().lower()

        if date_text == 'today':
        
            return datetime.today().strftime("%Y-%m-%d")

        try:
            datetime.strptime(date_text , "%Y-%m-%d")
            return date_text
        except ValueError:
            print("format tarikh ro eshtebah vared kardi. mesal dorost: 2026-08-28")


def add():

    def get_title():
        while True:
            title = input("title do(hadeaghal 2 character): ").strip()
            if len(title) >= 2:
                return title
            print("title nmitavanad kamtar az 2 character bashad")


    def get_priority():
        valid_priorities = ["low" , "medium" , "high"]
        while True:
            priority = input("priority(low , medium , high): ").strip().lower()
            if priority in valid_priorities:
                return priority
            print("lotfan dar vared kardan deghta konid (low , medium , high)")


    title = get_title()
    explain = input("explain do: ").strip()
    priority = get_priority()
    date = get_date()


    

    data = {
        'title': title ,
        'explain': explain ,
        'priority': priority , 
        'date' : date ,
        'done' : 'no'
    }

    file_exists = os.path.exists("do.csv")
    with open ('do.csv' , mode='a' , encoding='UTF-8' , newline='' ) as file:
        write = csv.DictWriter(file , fieldnames=fieldname )
        
        if not file_exists:
            write.writeheader()

        write.writerow(data)

    tasks = load_tasks()
    save_tasks(tasks)

    print("kar jadid zakhire shod")   
    





def edit():
    tasks = load_tasks()
    show()

    def get_bakhsh():
        valid_bakhsh = ['title','explain','priority','date']
        while True:
            bakhsh = input("che bakhshi ro mikhay taghir bedi(title/explain/priority/date): ")
            if bakhsh in valid_bakhsh:
                return bakhsh
            print("lotfan dar vared kardan khod deghat kond")



    while True:

        try:
            numb = int(input("che kari ro mikhayin edit konid(shomare an ra vared konid): "))
            if numb < 1 or numb > len(tasks):
                print("az edit kharej mishavid")
                return
            
            bakhsh = get_bakhsh()
            edited = tasks[numb-1]
            new = input("baksh jadid ro begoyid: ")
            tasks[numb-1][bakhsh] = new
            save_tasks(tasks)
            break
        except ValueError:
            print("lotfan adad vared konid")

    print(f"bakshe: {bakhsh} kar: {edited['title']} taghir peyda kard")



def remove():
    tasks = load_tasks()
    show()


    while True:
        try:
            numb = int(input("che kari makhahid hazf shavad(baraye kharej shodan adadi vared konid ke dar kar ha nabashad): "))
            if numb < 1 or numb > len(tasks):
                print("az remove kharej mishavid")
                return
            remove_task = tasks.pop(numb-1)
            break
        except ValueError:
            print("lotfan adad vared konid")

        
    save_tasks(tasks)
    print(f"kar: {remove_task['title']} hazf shod")


def load_tasks():
    if not os.path.exists("do.csv"):
        return []

    with open("do.csv", mode="r", encoding="UTF-8", newline="") as file:
        reader = csv.DictReader(file)
        return list(reader)


def save_tasks(tasks):
    sort_tasks = sorted(tasks , key= lambda task: datetime.strptime(task['date'], "%Y-%m-%d"))
    with open('do.csv', mode='w', newline='', encoding='UTF-8') as file:
        write = csv.DictWriter(file, fieldnames=fieldname)
        write.writeheader()
        write.writerows(sort_tasks)
        


def show():
    tasks = load_tasks()

    if not tasks:
        print("hish kari vojod nadarad")
        return []
    

    for i, do in enumerate(tasks, start=1):
        print(f"{i}. {do['title']}")
    


def show_by_date():
    date = get_date()
    show_tasks(search_by_date(date))
    return
    
                     

def show_tasks(tasks):

    if not tasks:
        print("hich kari baraye namayesh nist")
        return
    
    
    for index , task in enumerate(tasks , start=1):
        status = "✅" if task['done'] == 'yes' else "❌"
        print(f"{index}. {task['title']} | explain: {task['explain']} | priority: {task['priority']} | date: {task['date']} | status: {status} ")

        

    # for i , do in enumerate(task, start=1):
    #     if i == numb :
    #         print(f"{do['title']}: {do['explain']}")

    return
def search_by_date(date):
    

    tasks = load_tasks()

    task_date = []
    for task in tasks:
        if task['date'] == date:
            task_date.append(task)

    if not task_date:
        print("hich kari dar in tarikh yaft nashod!!")
        return []
    return task_date


def show_today():
    today = datetime.today().strftime("%Y-%m-%d")
    tasks_today = search_by_date(today)
    show_tasks(tasks_today)
    

def search_by_task():

    title_search = input("what search title: ").strip()
    tasks = load_tasks()
    for task in tasks:
        if task['title'].lower() == title_search.lower():
            print("kar mored nazar yaft shod")
            return task
        
            
    print(f"hich kary ba in onvan {title_search} yaft nashod")


def correct_task():

    tasks = load_tasks()
    today = datetime.today().strftime("%Y-%m-%d")

    for i , do in enumerate(tasks , start=1):
        if do['date'] == today:
            print(f"{i}. {do['title']}")

    dones = input("lotfan tamam kar hayi ke anjam dadid adad an ra ba deghat vared namayid(beyn har kari ke adadesho vared mikonid fasele bezarid)").strip().split()

    for i in dones:
        tasks[int(i)-1]['done'] = 'yes' 

    save_tasks(tasks)
    print("karhaye anjam shode zakhire shodand")

        

# import os

# print("مسیر فعلی:", os.getcwd())  # ببینید کد از کجا اجرا میشه

# file_exists = os.path.exists("do.csv")
# print("آیا فایل در مسیر جاری هست؟", file_exists)

# add()
# remove()
# edit()
# show()
# show_do()

def main():

    print("-"*60)
    print("Welcome to the Todo List")
    print("-"*60)
    while True:

        print("Menu📖:")
        print("♦️ 1. Add Task")
        print("♦️ 2. Edit Task")
        print("♦️ 3. Remove Task")
        print("♦️ 4. Show Task")
        print("♦️ 5. Show Today's Task")
        print("♦️ 6. Search Task")
        print("♦️ 7. Mark Task as Done")
        print("♦️ 8. Exit")
        print("~"*60)

        chois = int(input("enter your number chois: "))
        
        match chois:
            
            case 1:
                print("Welcome to Part Add ")
                add()

            case 2:
                print("Welcome to Part Edit ")
                edit()

            case 3:
                print("Welcome to Part Remove ")
                remove()

            case 4:
                print("Welcome to Part Show Tasks ")
                tasks = load_tasks()
                show_tasks(tasks)

            case 5:
                print("Welcome to Part Today Tasks ")
                show_today()

            case 6:
                print("Welcome to Part Search ")

                print("1. Search by date")
                print("2. Search by task")

                chois_search = int(input("Choses search: "))

                match chois_search:
                    case 1:
                        show_by_date()
                    case 2:
                        search_by_task()
            
            case 7:
                print("Welcome to Part Mark as done")
                correct_task()

            case 8:
                print("Good bye")
                print("Darhale khoroj az barname ...")
                print("Kharej shodi.")
                break

if __name__ == "__main__":
    main()




